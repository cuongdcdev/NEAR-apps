import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Hello CodeSandbo!!x</h1>
      <h2>Edit to see some masdasdagic happen!</h2>
    </div>
  );
}
